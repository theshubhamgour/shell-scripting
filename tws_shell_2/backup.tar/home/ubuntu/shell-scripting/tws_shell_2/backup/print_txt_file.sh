#!/bin/bash

for FILE in *.txt
do echo "Files Present in this directory are - $FILE "
done	
